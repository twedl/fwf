Two copies of people.cp850.txt.
